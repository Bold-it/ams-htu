const cron = require('node-cron');
/*************************************************
 *  HTU ACCREDITATION MONITORING SYSTEM          *
 *  Developed by: ICT Directorate                 *
 *  Year: 2026                                   *
 *************************************************/

const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const { sendEmail, verifyConnection } = require('./email-service');
const { OAuth2Client } = require('google-auth-library');
const crypto = require('crypto');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const xlsx = require('xlsx');

require('dotenv').config();

const app = express();
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);


const allowedOrigins = [process.env.FRONTEND_URL, 'https://test.htu.edu.gh', 'http://localhost:8080'].filter(Boolean);
app.use(cors({ 
    origin: (origin, callback) => {
        if (!origin || allowedOrigins.includes(origin) || allowedOrigins.includes('*')) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    }
}));

// Passenger Middleware: If requests arrive without /api (stripped by cPanel),
// rewrite them to include it so our routes match.
app.use((req, res, next) => {
    if (!req.url.startsWith('/api/') && req.url !== '/api') {
        req.url = '/api' + req.url;
    }
    next();
});

app.use(express.json());

// Security headers for Google Auth / COOP
app.use((req, res, next) => {
    res.setHeader('Cross-Origin-Opener-Policy', 'same-origin-allow-popups');
    res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp');
    next();
});

// Multer Configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + file.originalname);
    }
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
});

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
});

// Auto-migration for Phase 2
async function runMigrations() {
    try {
        console.log('Checking database schema...');

        // Helper to add column if missing
        const addColumn = async (colName, definition) => {
            const [columns] = await pool.query(
                'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = "accreditations" AND COLUMN_NAME = ?',
                [process.env.DB_NAME, colName]
            );
            if (columns.length === 0) {
                await pool.query(`ALTER TABLE accreditations ADD COLUMN ${colName} ${definition}`);
                console.log(`Added column ${colName} to accreditations table.`);
            }
        };

        await addColumn('faculty', 'VARCHAR(255)');
        await addColumn('department', 'VARCHAR(255)');
        
        // Users table updates
        const [userColumns] = await pool.query(
            'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = "users" AND COLUMN_NAME = "department"',
            [process.env.DB_NAME]
        );
        if (userColumns.length === 0) {
            await pool.query('ALTER TABLE users ADD COLUMN department VARCHAR(255) NULL AFTER role');
            console.log('Added column department to users table.');
        }

        console.log('Database schema is up to date.');
    } catch (err) {
        console.error('Migration error:', err.message);
    }
}
runMigrations();

// Audit Middleware
const auditMiddleware = async (req, res, next) => {
    // Only log mutations and specific GETs
    // Exclude audit logs to avoid loops
    if (req.path === '/api/audit-logs' || req.path === '/api/audit-analytics') return next();

    // Store start time for duration tracking if needed
    const start = Date.now();

    // Listen for the response to finish
    res.on('finish', async () => {
        const userEmail = req.headers['x-user-email'] || 'anonymous';
        const method = req.method;
        const path = req.path;
        const ip = req.ip || req.connection.remoteAddress;
        const statusCode = res.statusCode;

        // Skip logging if it's a non-mutating GET that succeeded and isn't specifically interesting
        // (This helps keep the logs manageable)
        const isMutation = ['POST', 'PUT', 'DELETE'].includes(method);
        const isLogin = path === '/api/login';
        
        if (!isMutation && !isLogin && statusCode < 400) return;

        // Determine a human readable action
        let action = `${method} ${path}`;
        if (path === '/api/login') action = 'User Login';
        if (path === '/api/upload') action = 'Excel Upload';
        if (path.startsWith('/api/accreditations')) {
            if (method === 'POST') action = 'Create Accreditation';
            if (method === 'PUT') action = 'Update Accreditation';
            if (method === 'DELETE') action = 'Delete Accreditation';
            if (method === 'GET' && path === '/api/accreditations') action = 'View Accreditations';
        }
        if (path === '/api/users/reset-password') action = 'Admin Reset Triggered';
        if (path === '/api/users' && method === 'POST') action = 'Create User Account';
        if (path.startsWith('/api/users/') && method === 'DELETE') action = 'Delete User Account';
        if (path.includes('/documents')) {
            if (method === 'POST') action = 'Upload Document';
            if (method === 'GET') action = 'View Documents';
            if (method === 'DELETE') action = 'Delete Document';
        }

        const details = JSON.stringify({
            body: req.body,
            query: req.query,
            params: req.params,
            resourceName: req.auditResourceName || null,
            duration: Date.now() - start,
            timestamp: new Date().toISOString()
        });

        try {
            await pool.query(
                'INSERT INTO audit_logs (user_email, action, method, path, details, ip_address, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [userEmail, action, method, path, details, ip, statusCode]
            );
        } catch (err) {
            console.error('Audit logging failed:', err);
        }
    });

    next();
};

app.use('/api', auditMiddleware);

app.get('/api/audit-logs', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);

        if (userRows.length === 0 || userRows[0].role !== 'super_admin') {
            return res.status(403).json({ error: 'Access denied. Super Admin only.' });
        }

        const [rows] = await pool.query('SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 500');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/audit-analytics', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);

        if (userRows.length === 0 || userRows[0].role !== 'super_admin') {
            return res.status(403).json({ error: 'Access denied. Super Admin only.' });
        }

        const today = new Date().toISOString().split('T')[0];

        // Total Actions Today
        const [totalToday] = await pool.query(
            'SELECT COUNT(*) as count FROM audit_logs WHERE DATE(timestamp) = ?',
            [today]
        );

        // Most Active Admin Today
        const [activeAdmin] = await pool.query(
            'SELECT user_email, COUNT(*) as count FROM audit_logs WHERE DATE(timestamp) = ? AND user_email != "anonymous" GROUP BY user_email ORDER BY count DESC LIMIT 1',
            [today]
        );

        // Last Critical Action (Delete)
        const [lastCritical] = await pool.query(
            'SELECT * FROM audit_logs WHERE action LIKE "%Delete%" ORDER BY timestamp DESC LIMIT 1'
        );

        res.json({
            totalActionsToday: totalToday[0]?.count || 0,
            mostActiveAdmin: activeAdmin[0]?.user_email || 'N/A',
            lastCriticalAction: lastCritical[0] || null
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

function getStatus(expiryDate) {
    const days = Math.floor((new Date(expiryDate) - new Date()) / 86400000);
    if (days <= 0) return { days, status: 'expired' };
    if (days <= 90) return { days, status: 'critical' };
    if (days <= 365) return { days, status: 'warning' };
    if (days <= 450) return { days, status: 'upcoming' };
    return { days, status: 'active' };
}

function getWorkflowLabel(status) {
    const labels = {
        self_assessment: "Self-Assessment",
        application_submitted: "Application Submitted",
        vetting: "GTEC Vetting",
        visitation: "GTEC Visitation",
        accredited: "Fully Accredited",
    };
    return labels[status] || status;
}

function transformRow(row) {
    const { days, status: currentStatus } = getStatus(row.expiry_date);
    const totalCp = parseInt(row.total_checkpoints || 0);
    const completedCp = parseInt(row.completed_checkpoints || 0);
    const completionPercentage = totalCp > 0 ? Math.round((completedCp / totalCp) * 100) : 0;

    return {
        id: row.id,
        programmeName: row.programme_name,
        accreditationType: row.accreditation_type || 'programme',
        faculty: row.faculty || '',
        department: row.department || '',
        startDate: row.start_date ? new Date(row.start_date).toISOString().split('T')[0] : '',
        expiryDate: new Date(row.expiry_date).toISOString().split('T')[0],
        email: row.email || '',
        workflowStatus: row.workflow_status || 'accredited',
        institutionId: row.institution_id || 'HTU',
        daysUntilExpiry: days,
        status: currentStatus,
        completionPercentage,
        documentCount: parseInt(row.document_count || 0),
        snoozedUntil: row.snoozed_until ? new Date(row.snoozed_until).toISOString().split('T')[0] : null
    };
}

const bcrypt = require('bcryptjs');

app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);

        if (rows.length === 0) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        const user = rows[0];

        if (user.status === 'pending_approval') {
            return res.status(403).json({ error: 'Your account is pending approval by the Super Admin.' });
        }

        const match = await bcrypt.compare(password, user.password_hash);


        if (!match) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        res.json({
            role: user.role,
            department: user.department,
            token: 'dummy-token',
            email: user.email
        });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/change-password', async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;
        const userEmail = req.headers['x-user-email'];

        if (!userEmail) return res.status(401).json({ error: 'Authentication required' });

        const [userRows] = await pool.query('SELECT * FROM users WHERE email = ?', [userEmail]);
        if (userRows.length === 0) return res.status(404).json({ error: 'User not found' });

        const user = userRows[0];

        // Self-service change REQUIRES current password
        if (!currentPassword) {
            return res.status(400).json({ error: 'Current password is required to change password' });
        }

        const match = await bcrypt.compare(currentPassword, user.password_hash);
        if (!match) return res.status(401).json({ error: 'Incorrect current password' });

        if (newPassword.length < 8) {
            return res.status(400).json({ error: 'New password must be at least 8 characters' });
        }

        const newHash = await bcrypt.hash(newPassword, 10);
        await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [newHash, user.id]);

        res.json({ success: true, message: 'Password changed successfully' });
    } catch (err) {
        console.error('Change password error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/forgot-password', async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) return res.status(400).json({ error: 'Email is required' });

        const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
        if (rows.length === 0) {
            // Don't reveal if user exists or not for security, but we'll assume valid for this internal system
            return res.json({ message: 'If an account exists with that email, a reset token has been sent.' });
        }

        const token = Math.floor(100000 + Math.random() * 900000).toString();
        const expiry = new Date(Date.now() + 3600000); // 1 hour

        await pool.query(
            'UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE email = ?',
            [token, expiry, email]
        );

        try {
            await sendEmail(
                email,
                'Password Reset - Accreditation Monitoring System',
                `
                <p>You requested a password reset.</p>
                <p>Your 6-digit verification code is: <strong style="font-size: 24px; letter-spacing: 5px;">${token}</strong></p>
                <p>This code will expire in 1 hour.</p>
                <p>If you did not request this, please ignore this email.</p>
                `
            );
        } catch (emailErr) {
            console.error('Failed to send reset email, rolling back token:', emailErr);
            // ROLLBACK: Clear the token so user can try again (or so others can't use an unseen token)
            await pool.query(
                'UPDATE users SET reset_token = NULL, reset_token_expiry = NULL WHERE email = ?',
                [email]
            );
            return res.status(500).json({ error: 'Failed to send reset email. Please try again later.' });
        }

        res.json({ success: true, message: 'Reset token sent to email' });
    } catch (err) {
        console.error('Forgot password error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/reset-password', async (req, res) => {
    try {
        const { token, newPassword } = req.body;
        if (!token || !newPassword) return res.status(400).json({ error: 'Token and new password are required' });

        if (newPassword.length < 8) {
            return res.status(400).json({ error: 'Password must be at least 8 characters' });
        }

        const [rows] = await pool.query(
            'SELECT * FROM users WHERE reset_token = ? AND reset_token_expiry > NOW()',
            [token]
        );

        if (rows.length === 0) {
            return res.status(401).json({ error: 'Invalid or expired reset token' });
        }

        const newHash = await bcrypt.hash(newPassword, 10);
        await pool.query(
            'UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?',
            [newHash, rows[0].id]
        );

        res.json({ success: true, message: 'Password reset successfully' });
    } catch (err) {
        console.error('Reset password error:', err);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/google-login', async (req, res) => {
    try {
        const { credential } = req.body;
        if (!credential) return res.status(400).json({ error: 'Google credential is required' });

        const ticket = await client.verifyIdToken({
            idToken: credential,
            audience: process.env.GOOGLE_CLIENT_ID,
        });

        const payload = ticket.getPayload();
        const { email, sub: googleId, name } = payload;

        // Restriction: Only allow @htu.edu.gh domain
        if (!email.endsWith('@htu.edu.gh')) {
            return res.status(403).json({ error: 'Only @htu.edu.gh email addresses are allowed.' });
        }

        // Check if user exists
        let [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
        let user;

        if (rows.length === 0) {
            // New user - create with pending_approval status
            const userId = crypto.randomUUID();
            user = {
                id: userId,
                username: name || email.split('@')[0],
                email: email,
                role: 'user',
                google_id: googleId,
                status: 'pending_approval'
            };

            await pool.query(
                'INSERT INTO users (id, username, email, role, google_id, status) VALUES (?, ?, ?, ?, ?, ?)',
                [user.id, user.username, user.email, user.role, user.google_id, user.status]
            );

            return res.json({
                status: 'pending_approval',
                message: 'Your account has been created and is pending approval by the Super Admin.'
            });
        } else {
            user = rows[0];

            // Link Google ID if not already linked
            if (!user.google_id) {
                await pool.query('UPDATE users SET google_id = ? WHERE id = ?', [googleId, user.id]);
            }

            if (user.status === 'pending_approval') {
                return res.status(403).json({
                    status: 'pending_approval',
                    error: 'Your account is pending approval by the Super Admin.'
                });
            }

            // Normal login
            res.json({
                role: user.role,
                department: user.department,
                token: 'google-auth-token', // In a real app, use JWT
                email: user.email
            });
        }
    } catch (err) {
        console.error('Google login error:', err);
        res.status(500).json({ error: 'Authentication failed' });
    }
});


app.post('/api/users/reset-password', async (req, res) => {
    try {
        const { userId } = req.body;
        const adminEmail = req.headers['x-user-email'];

        // 1. Verify Super Admin privileges
        const [adminRows] = await pool.query('SELECT role FROM users WHERE email = ?', [adminEmail]);
        if (adminRows.length === 0 || adminRows[0].role !== 'super_admin') {
            return res.status(403).json({ error: 'Only Super Admin can trigger administrative resets' });
        }

        // 2. Fetch target user
        const [userRows] = await pool.query('SELECT email FROM users WHERE id = ?', [userId]);
        if (userRows.length === 0) return res.status(404).json({ error: 'User not found' });
        const targetEmail = userRows[0].email;
        req.auditResourceName = targetEmail;

        // 3. Generate token
        const token = Math.floor(100000 + Math.random() * 900000).toString();
        const expiry = new Date(Date.now() + 3600000); // 1 hour

        await pool.query(
            'UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?',
            [token, expiry, userId]
        );

        // 4. Send reset email
        await sendEmail(
            targetEmail,
            'Administrative Password Reset - HTU Accreditation System',
            `
            <p>An administrative password reset has been triggered for your account.</p>
            <p>Your 6-digit verification code is: <strong style="font-size: 24px; letter-spacing: 5px;">${token}</strong></p>
            <p>This code will expire in 1 hour. Please use it on the login page to set a new password.</p>
            <p>If you have any questions, please contact the System Master.</p>
            `
        );

        res.json({ success: true, message: `Reset token sent to ${targetEmail}` });
    } catch (err) {
        console.error('Admin reset error:', err);
        res.status(500).json({ error: err.message });
    }
});

// User Management Endpoints (Super Admin Only)
app.get('/api/users', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);

        if (userRows.length === 0 || userRows[0].role !== 'super_admin') {
            return res.status(403).json({ error: 'Access denied. Super Admin only.' });
        }

        const [rows] = await pool.query('SELECT id, username, email, role, status, created_at FROM users');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/users', async (req, res) => {
    try {
        const adminEmail = req.headers['x-user-email'];
        const [adminRows] = await pool.query('SELECT role FROM users WHERE email = ?', [adminEmail]);

        if (adminRows.length === 0 || adminRows[0].role !== 'super_admin') {
            return res.status(403).json({ error: 'Access denied. Super Admin only.' });
        }

        const { username, email, password, role } = req.body;
        req.auditResourceName = username || email;
        if (!username || !email || !password || !role) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        if (password.length < 8) {
            return res.status(400).json({ error: 'Password must be at least 8 characters' });
        }

        const passwordHash = await bcrypt.hash(password, 10);
        await pool.query(
            'INSERT INTO users (id, username, email, password_hash, role) VALUES (?, ?, ?, ?, ?)',
            [crypto.randomUUID(), username, email, passwordHash, role]
        );

        // Send welcome email to newly created user
        try {
            await sendEmail(
                email,
                'Account Created - HTU Accreditation Monitoring System',
                `
                <h2>Welcome to HTU Quality Assurance</h2>
                <p>Hello ${username},</p>
                <p>Your account has been successfully created by the Super Admin.</p>
                <p><strong>Account Role:</strong> ${role === 'admin' ? 'Administrator' : 'Viewer'}</p>
                <p>You can now log in to the portal using your credentials.</p>
                <p><a href="${process.env.FRONTEND_URL || 'http://localhost:8080'}/login" style="display: inline-block; padding: 10px 20px; background-color: #0056b3; color: white; text-decoration: none; border-radius: 5px;">Login to Portal</a></p>
                <p>Best regards,<br>The HTU Team</p>
                `
            );
        } catch (emailErr) {
            console.error('Failed to send welcome email:', emailErr);
        }

        res.json({ success: true, message: 'User created successfully and notification sent' });
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(400).json({ error: 'Username or email already exists' });
        }
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/users/:id', async (req, res) => {
    try {
        const adminEmail = req.headers['x-user-email'];
        const [adminRows] = await pool.query('SELECT role FROM users WHERE email = ?', [adminEmail]);

        if (adminRows.length === 0 || adminRows[0].role !== 'super_admin') {
            return res.status(403).json({ error: 'Access denied. Super Admin only.' });
        }

        const { id } = req.params;
        const [uRows] = await pool.query('SELECT username, email FROM users WHERE id = ?', [id]);
        if (uRows.length > 0) req.auditResourceName = uRows[0].username || uRows[0].email;

        const [result] = await pool.query('DELETE FROM users WHERE id = ? AND role != "super_admin"', [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'User not found or cannot delete super admin' });
        }

        res.json({ success: true, message: 'User deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/users/:id/approve', async (req, res) => {
    try {
        const adminEmail = req.headers['x-user-email'];
        const [adminRows] = await pool.query('SELECT role FROM users WHERE email = ?', [adminEmail]);

        if (adminRows.length === 0 || adminRows[0].role !== 'super_admin') {
            return res.status(403).json({ error: 'Access denied. Super Admin only.' });
        }

        const { id } = req.params;
        const [userRows] = await pool.query('SELECT * FROM users WHERE id = ?', [id]);

        if (userRows.length === 0) return res.status(404).json({ error: 'User not found' });
        const user = userRows[0];

        if (user.status === 'active') {
            return res.status(400).json({ error: 'User is already active' });
        }

        await pool.query('UPDATE users SET status = "active" WHERE id = ?', [id]);

        // Send congratulations email
        try {
            await sendEmail(
                user.email,
                'Account Approved - HTU Accreditation Monitoring System',
                `
                <h2>Congratulations!</h2>
                <p>Hello ${user.username || 'User'},</p>
                <p>Your account on the HTU Accreditation Monitoring System has been approved by the Super Admin.</p>
                <p>You can now log in using your Google account at the portal.</p>
                <p>Best regards,<br>The HTU Team</p>
                `
            );
        } catch (emailErr) {
            console.error('Failed to send approval email:', emailErr);
        }

        res.json({ success: true, message: 'User approved successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});



app.get('/api/accreditations', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT 
                a.*, 
                COALESCE(cp.total, 0) as total_checkpoints, 
                COALESCE(cp.completed, 0) as completed_checkpoints,
                COALESCE(doc.count, 0) as document_count
            FROM accreditations a
            LEFT JOIN (
                SELECT accreditation_id, COUNT(*) as total, SUM(is_completed) as completed 
                FROM accreditation_checkpoints 
                GROUP BY accreditation_id
            ) cp ON a.id = cp.accreditation_id
            LEFT JOIN (
                SELECT accreditation_id, COUNT(*) as count 
                FROM accreditation_documents 
                GROUP BY accreditation_id
            ) doc ON a.id = doc.accreditation_id
            ORDER BY a.expiry_date ASC
        `);
        res.json(rows.map(transformRow));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Export accreditations to Excel
app.get('/api/export-accreditations', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT 
                programme_name as 'Programme Name',
                accreditation_type as 'Type',
                faculty as 'Faculty',
                department as 'Department',
                start_date as 'Start Date',
                expiry_date as 'Expiry Date',
                email as 'Contact Email',
                workflow_status as 'Workflow Status'
            FROM accreditations
            ORDER BY expiry_date ASC
        `);

        if (rows.length === 0) {
            return res.status(404).json({ error: 'No data found to export' });
        }

        // Create a new workbook and worksheet
        const wb = xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(rows);

        // Add worksheet to workbook
        xlsx.utils.book_append_sheet(wb, ws, 'Accreditations');

        // Generate Excel file buffer
        const excelBuffer = xlsx.write(wb, { type: 'buffer', bookType: 'xlsx' });

        // Set headers for file download
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', 'attachment; filename="HTU_Accreditations_Registry.xlsx"');

        // Log the download action
        const userEmail = req.headers['x-user-email'] || 'anonymous';
        await pool.query(
            'INSERT INTO audit_logs (user_email, action, method, path, details, ip_address, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [userEmail, 'Export Registry', 'GET', req.originalUrl, `Exported ${rows.length} accreditations to Excel`, req.ip, 200]
        );

        res.send(excelBuffer);
    } catch (err) {
        console.error('Export error:', err);
        res.status(500).json({ error: 'Failed to generate Excel file' });
    }
});

app.get('/api/accreditations/:id', async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT 
                a.*, 
                COALESCE(cp.total, 0) as total_checkpoints, 
                COALESCE(cp.completed, 0) as completed_checkpoints,
                COALESCE(doc.count, 0) as document_count
            FROM accreditations a
            LEFT JOIN (
                SELECT accreditation_id, COUNT(*) as total, SUM(is_completed) as completed 
                FROM accreditation_checkpoints 
                GROUP BY accreditation_id
            ) cp ON a.id = cp.accreditation_id
            LEFT JOIN (
                SELECT accreditation_id, COUNT(*) as count 
                FROM accreditation_documents 
                GROUP BY accreditation_id
            ) doc ON a.id = doc.accreditation_id
            WHERE a.id = ?
        `, [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Not found' });
        res.json(transformRow(rows[0]));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/accreditations', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);
        if (userRows.length === 0 || (userRows[0].role !== 'admin' && userRows[0].role !== 'super_admin')) {
            return res.status(403).json({ error: 'Permission denied' });
        }

        const { 
            programme_name, 
            accreditation_type, 
            faculty, 
            department, 
            start_date, 
            expiry_date, 
            email,
            workflow_status,
            institution_id
        } = req.body;

        req.auditResourceName = programme_name;
        
        const id = crypto.randomUUID();
        await pool.query(
            'INSERT INTO accreditations (id, programme_name, accreditation_type, faculty, department, start_date, expiry_date, email, workflow_status, institution_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                id, 
                programme_name, 
                accreditation_type || 'programme',
                faculty || null, 
                department || null, 
                start_date || null, 
                expiry_date, 
                email || null,
                workflow_status || 'accredited',
                institution_id || 'HTU'
            ]
        );
        const [rows] = await pool.query(`
            SELECT 
                a.*, 
                COALESCE(cp.total, 0) as total_checkpoints, 
                COALESCE(cp.completed, 0) as completed_checkpoints,
                COALESCE(doc.count, 0) as document_count
            FROM accreditations a
            LEFT JOIN (
                SELECT accreditation_id, COUNT(*) as total, SUM(is_completed) as completed 
                FROM accreditation_checkpoints 
                GROUP BY accreditation_id
            ) cp ON a.id = cp.accreditation_id
            LEFT JOIN (
                SELECT accreditation_id, COUNT(*) as count 
                FROM accreditation_documents 
                GROUP BY accreditation_id
            ) doc ON a.id = doc.accreditation_id
            WHERE a.id = ?
        `, [id]);

        // Send welcome email if email is provided
        if (email) {
            try {
                const { days } = getStatus(expiry_date);
                await sendEmail(
                    email,
                    `Accreditation Registered: ${programme_name}`,
                    `
                        <h2>Welcome to HTU Accreditation Monitoring System</h2>
                        <p>Your programme has been successfully registered in our accreditation monitoring system.</p>
                        <h3>Programme Details:</h3>
                        <ul>
                            <li><strong>Programme:</strong> ${programme_name}</li>
                            <li><strong>Expiry Date:</strong> ${expiry_date}</li>
                            <li><strong>Days Until Expiry:</strong> ${days} days</li>
                        </ul>
                        <p>You will receive automatic reminder emails at key intervals: 1 year, 6 months, 1 month, 2 weeks, 1 week, and 1 day before expiry.</p>
                    `
                );
            } catch (emailErr) {
                console.error(`Failed to send welcome email:`, emailErr);
                // Don't fail the request if email fails
            }
        }

        res.status(201).json(transformRow(rows[0]));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/accreditations/:id', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);
        if (userRows.length === 0 || (userRows[0].role !== 'admin' && userRows[0].role !== 'super_admin')) {
            return res.status(403).json({ error: 'Permission denied' });
        }

        const { 
            programme_name, 
            accreditation_type, 
            faculty, 
            department, 
            start_date, 
            expiry_date, 
            email,
            workflow_status,
            institution_id,
            snoozed_until
        } = req.body;
        
        req.auditResourceName = programme_name || `Accreditation ID: ${req.params.id}`;
        
        // Fetch current state for notification check
        const [currentRow] = await pool.query('SELECT workflow_status, email, programme_name FROM accreditations WHERE id = ?', [req.params.id]);
        const oldStatus = currentRow[0]?.workflow_status;
        const targetEmail = email || currentRow[0]?.email;

        await pool.query(
            'UPDATE accreditations SET programme_name = ?, accreditation_type = ?, faculty = ?, department = ?, start_date = ?, expiry_date = ?, email = ?, workflow_status = ?, institution_id = ?, snoozed_until = ? WHERE id = ?',
            [
                programme_name, 
                accreditation_type,
                faculty || null, 
                department || null, 
                start_date || null, 
                expiry_date, 
                email || null, 
                workflow_status,
                institution_id,
                snoozed_until || null,
                req.params.id
            ]
        );

        // Send notification if stage changed
        if (workflow_status && oldStatus && workflow_status !== oldStatus && targetEmail) {
            try {
                await sendEmail(
                    targetEmail,
                    `Workflow Update: ${programme_name} - ${getWorkflowLabel(workflow_status)}`,
                    `
                    <h2>Accreditation Stage Updated</h2>
                    <p>The accreditation process for <strong>${programme_name}</strong> has moved to a new stage.</p>
                    <p><strong>Previous Stage:</strong> ${getWorkflowLabel(oldStatus)}</p>
                    <p><strong>New Stage:</strong> <span style="color: #0056b3; font-weight: bold;">${getWorkflowLabel(workflow_status)}</span></p>
                    <p>Please log in to the portal to view more details or upload required documents.</p>
                    <p>Best regards,<br>Quality Assurance Unit</p>
                    `
                );
            } catch (emailErr) {
                console.error('Failed to send workflow update email:', emailErr);
            }
        }

        const [rows] = await pool.query(`
            SELECT 
                a.*, 
                COALESCE(cp.total, 0) as total_checkpoints, 
                COALESCE(cp.completed, 0) as completed_checkpoints,
                COALESCE(doc.count, 0) as document_count
            FROM accreditations a
            LEFT JOIN (
                SELECT accreditation_id, COUNT(*) as total, SUM(is_completed) as completed 
                FROM accreditation_checkpoints 
                GROUP BY accreditation_id
            ) cp ON a.id = cp.accreditation_id
            LEFT JOIN (
                SELECT accreditation_id, COUNT(*) as count 
                FROM accreditation_documents 
                GROUP BY accreditation_id
            ) doc ON a.id = doc.accreditation_id
            WHERE a.id = ?
        `, [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Not found' });
        res.json(transformRow(rows[0]));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


app.delete('/api/accreditations/:id', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);
        if (userRows.length === 0 || (userRows[0].role !== 'admin' && userRows[0].role !== 'super_admin')) {
            return res.status(403).json({ error: 'Permission denied' });
        }

        // Fetch name before deletion
        const [rows] = await pool.query('SELECT programme_name FROM accreditations WHERE id = ?', [req.params.id]);
        if (rows.length > 0) req.auditResourceName = rows[0].programme_name;

        await pool.query('DELETE FROM accreditations WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/metrics', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM accreditations');
        const metrics = { total: rows.length, active: 0, warning: 0, critical: 0, expired: 0, upcoming: 0 };
        rows.forEach(row => { 
            const status = getStatus(row.expiry_date).status;
            if (metrics.hasOwnProperty(status)) {
                metrics[status]++;
            }
        });
        res.json(metrics);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/send-reminder/:id', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);
        if (userRows.length === 0 || (userRows[0].role !== 'admin' && userRows[0].role !== 'super_admin')) {
            return res.status(403).json({ error: 'Permission denied' });
        }

        const [rows] = await pool.query('SELECT * FROM accreditations WHERE id = ?', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Not found' });
        const acc = rows[0];
        if (!acc.email) return res.status(400).json({ error: 'No email address' });
        const { days } = getStatus(acc.expiry_date);

        const result = await sendEmail(
            acc.email,
            `Accreditation Reminder: ${acc.programme_name}`,
            `<p>The accreditation for <strong>${acc.programme_name}</strong> expires in ${days} days.</p>`
        );

        if (result.success) {
            res.json({ success: true, messageId: result.messageId });
        } else {
            res.status(500).json({ success: false, error: result.error });
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/send-bulk-reminders', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);
        if (userRows.length === 0 || (userRows[0].role !== 'admin' && userRows[0].role !== 'super_admin')) {
            return res.status(403).json({ error: 'Permission denied' });
        }

        const { status: filterStatus } = req.body;
        const [rows] = await pool.query('SELECT * FROM accreditations WHERE email IS NOT NULL');
        const results = [];
        for (const row of rows) {
            // Check if snoozed
            if (row.snoozed_until && new Date(row.snoozed_until) > new Date()) {
                continue;
            }

            const { days, status } = getStatus(row.expiry_date);
            let shouldSend = false;
            if (filterStatus === 'warning' && status === 'warning') shouldSend = true;
            else if (filterStatus === 'critical' && (status === 'critical' || status === 'expired')) shouldSend = true;
            else if (filterStatus === 'all' && status !== 'active') shouldSend = true;
            if (!shouldSend) continue;

            const result = await sendEmail(
                row.email,
                `Accreditation Reminder: ${row.programme_name}`,
                `<p>The accreditation for <strong>${row.programme_name}</strong> expires in ${days} days.</p>`
            );
            results.push({ id: row.id, success: result.success, error: result.error });
        }
        res.json({ sent: results.filter(r => r.success).length, results });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

async function getMonthlyReportContent() {
    try {
        const [rows] = await pool.query('SELECT * FROM accreditations');
        
        // Fetch readiness stats
        const [checkpoints] = await pool.query(`
            SELECT accreditation_id, COUNT(*) as total, SUM(is_completed) as completed 
            FROM accreditation_checkpoints 
            GROUP BY accreditation_id
        `);
        const checkpointMap = {};
        checkpoints.forEach(c => {
            checkpointMap[c.accreditation_id] = {
                total: c.total,
                completed: parseInt(c.completed || 0)
            };
        });

        // Fetch document stats
        const [docs] = await pool.query(`
            SELECT accreditation_id, COUNT(*) as count 
            FROM accreditation_documents 
            GROUP BY accreditation_id
        `);
        const docMap = {};
        docs.forEach(d => {
            docMap[d.accreditation_id] = d.count;
        });

        const metrics = { total: rows.length, active: 0, upcoming: 0, warning: 0, critical: 0, expired: 0 };
        rows.forEach(row => { 
            const status = getStatus(row.expiry_date).status;
            if (metrics.hasOwnProperty(status)) {
                metrics[status]++;
            }
        });

        const statusGroups = {
            expired: [],
            critical: [],
            warning: [],
            upcoming: [],
            active: []
        };

        rows.forEach(row => {
            const status = getStatus(row.expiry_date).status;
            if (statusGroups[status]) {
                statusGroups[status].push(row);
            }
        });

        // Sort all programmes for the broader status section
        const sortedProgrammes = [...rows].sort((a, b) => new Date(a.expiry_date) - new Date(b.expiry_date));

        const html = `
            <div style="font-family: Arial, sans-serif; color: #333; max-width: 800px; margin: 0 auto;">
                <h2 style="color: #1e3a8a; border-bottom: 2px solid #1e3a8a; padding-bottom: 10px;">Monthly Accreditation Status Report</h2>
                <p><strong>Institution:</strong> Ho Technical University</p>
                <p><strong>Date:</strong> ${new Date().toLocaleDateString('default', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                
                <h3 style="color: #1e3a8a; margin-top: 25px;">1. Executive Summary</h3>
                <table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%; max-width: 500px; border: 1px solid #e2e8f0;">
                    <tr style="background-color: #f8fafc;">
                        <td><strong>Total Registered Programmes</strong></td>
                        <td align="right">${metrics.total}</td>
                    </tr>
                    <tr>
                        <td style="color: #16a34a;"><strong>Active (>15 Months)</strong></td>
                        <td align="right">${metrics.active}</td>
                    </tr>
                    <tr>
                        <td style="color: #2563eb;"><strong>Upcoming Renewal (≤15 Months)</strong></td>
                        <td align="right">${metrics.upcoming}</td>
                    </tr>
                    <tr>
                        <td style="color: #ca8a04;"><strong>Warning Phase (≤12 Months)</strong></td>
                        <td align="right">${metrics.warning}</td>
                    </tr>
                    <tr>
                        <td style="color: #dc2626;"><strong>Critical Phase (≤3 Months)</strong></td>
                        <td align="right">${metrics.critical}</td>
                    </tr>
                    <tr style="background-color: #fef2f2;">
                        <td style="color: #7f1d1d;"><strong>EXPIRED</strong></td>
                        <td align="right">${metrics.expired}</td>
                    </tr>
                </table>

                <h3 style="color: #1e3a8a; margin-top: 25px;">2. Detailed Programme Status Breakdown</h3>
                <p style="font-size: 0.9em; color: #64748b; margin-bottom: 15px;">Listing all registered programmes by their current compliance phase.</p>

                ${Object.entries(statusGroups).map(([status, progs]) => {
                    if (progs.length === 0) return '';
                    
                    let statusLabel = '';
                    let statusColor = '#000';
                    let bgColor = '#f8fafc';

                    if (status === 'expired') { statusLabel = 'EXPIRED'; statusColor = '#7f1d1d'; bgColor = '#fef2f2'; }
                    else if (status === 'critical') { statusLabel = 'CRITICAL PHASE (≤ 3 Months)'; statusColor = '#dc2626'; bgColor = '#fff1f2'; }
                    else if (status === 'warning') { statusLabel = 'WARNING PHASE (≤ 12 Months)'; statusColor = '#ca8a04'; bgColor = '#fefce8'; }
                    else if (status === 'upcoming') { statusLabel = 'UPCOMING RENEWAL (12-15 Months)'; statusColor = '#2563eb'; bgColor = '#eff6ff'; }
                    else if (status === 'active') { statusLabel = 'ACTIVE (> 15 Months)'; statusColor = '#16a34a'; bgColor = '#f0fdf4'; }

                    return `
                        <div style="margin-bottom: 20px; border: 1px solid #e2e8f0; border-radius: 6px; overflow: hidden;">
                            <div style="background-color: ${bgColor}; padding: 10px; border-bottom: 1px solid #e2e8f0;">
                                <strong style="color: ${statusColor}; text-transform: uppercase;">${statusLabel}</strong> 
                                <span style="float: right; background-color: ${statusColor}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.8em;">${progs.length}</span>
                                <div style="clear: both;"></div>
                            </div>
                            <table border="0" cellpadding="8" style="width: 100%; border-collapse: collapse;">
                                ${progs.map(p => `
                                    <tr style="border-bottom: 1px solid #f1f5f9;">
                                        <td style="width: 60%;"><strong>${p.programme_name}</strong><br><small style="color: #64748b;">${p.department || 'No Department'}</small></td>
                                        <td align="right" style="font-size: 0.9em;">Expires: ${new Date(p.expiry_date).toLocaleDateString()}</td>
                                    </tr>
                                `).join('')}
                            </table>
                        </div>
                    `;
                }).join('')}

                <h3 style="color: #1e3a8a; margin-top: 25px;">3. Internal Quality Readiness & Documentation Status</h3>
                <p style="font-size: 0.9em; color: #64748b;">This section tracks the internal preparation for GTEC submission and the status of the institutional document vault.</p>
                <table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%; border: 1px solid #e2e8f0;">
                    <thead>
                        <tr style="background-color: #f1f5f9;">
                            <th align="left">Programme</th>
                            <th align="left">Workflow Stage</th>
                            <th align="left">Internal Readiness</th>
                            <th align="left">Documents</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${sortedProgrammes.map(p => {
                            const cp = checkpointMap[p.id] || { total: 0, completed: 0 };
                            const docCount = docMap[p.id] || 0;
                            const percent = cp.total > 0 ? Math.round((cp.completed / cp.total) * 100) : 0;
                            const stageLabel = getWorkflowLabel(p.workflow_status);
                            
                            return `
                                <tr>
                                    <td>${p.programme_name}</td>
                                    <td>${stageLabel}</td>
                                    <td>
                                        <div style="width: 100px; height: 8px; background-color: #e2e8f0; border-radius: 4px; overflow: hidden; display: inline-block; vertical-align: middle;">
                                            <div style="width: ${percent}%; height: 100%; background-color: ${percent === 100 ? '#16a34a' : '#2563eb'};"></div>
                                        </div>
                                        <span style="font-size: 0.85em; margin-left: 5px;">${percent}%</span>
                                    </td>
                                    <td align="center" style="font-size: 0.9em;">${docCount} files</td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>

                <p style="margin-top: 40px; padding-top: 15px; border-top: 1px solid #e2e8f0; font-size: 0.85em; color: #64748b; line-height: 1.6;">
                    <strong>Office of the Pro-Vice-Chancellor</strong><br>
                    Quality Assurance Unit, Ho Technical University<br>
                    <em>Note: This is an official automated report generated by the Accreditation Monitoring System. All readiness data and document counts are reflected in real-time.</em>
                </p>
            </div>
        `;
        return { success: true, html, metrics };
    } catch (err) {
        return { success: false, error: err.message };
    }
}

async function sendMonthlyReport() {
    console.log('Generating monthly Pro-VC report...');
    const result = await getMonthlyReportContent();
    if (!result.success) {
        console.error('Error generating monthly report:', result.error);
        return result;
    }

    try {
        await sendEmail(
            'provc@htu.edu.gh, accreditationsystem@htu.edu.gh',
            `Monthly Accreditation Status Report - ${new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}`,
            result.html
        );
        console.log('Monthly report sent to Pro-VC and System Email.');
        return { success: true };
    } catch (err) {
        console.error('Error sending monthly report:', err);
        return { success: false, error: err.message };
    }
}

app.get('/api/monthly-report-preview', async (req, res) => {
    const result = await getMonthlyReportContent();
    if (result.success) {
        res.json({ html: result.html });
    } else {
        res.status(500).json({ error: result.error });
    }
});

app.post('/api/send-monthly-report', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);
        if (userRows.length === 0 || (userRows[0].role !== 'admin' && userRows[0].role !== 'super_admin')) {
            return res.status(403).json({ error: 'Permission denied' });
        }

        const result = await sendMonthlyReport();
        if (result.success) {
            res.json({ success: true, message: 'Monthly report sent to Pro-VC' });
        } else {
            res.status(500).json({ error: result.error });
        }
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- Document Management Routes ---

// Upload document for an accreditation
app.post('/api/accreditations/:id/documents', upload.single('file'), async (req, res) => {
    const { id } = req.params;
    const { document_type, notes } = req.body;
    const file = req.file;

    if (!file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    
    req.auditResourceName = file.originalname;

    try {
        const [result] = await pool.query(
            'INSERT INTO accreditation_documents (accreditation_id, document_type, file_name, file_path, size_bytes, mime_type, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [id, document_type || 'other', file.originalname, file.filename, file.size, file.mimetype, notes || '']
        );

        res.json({ 
            success: true, 
            documentId: result.insertId,
            fileName: file.originalname 
        });
    } catch (err) {
        console.error('Error uploading document:', err);
        res.status(500).json({ error: 'Failed to save document metadata' });
    }
});

// List documents for an accreditation
app.get('/api/accreditations/:id/documents', async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query(
            'SELECT * FROM accreditation_documents WHERE accreditation_id = ? ORDER BY uploaded_at DESC',
            [id]
        );
        res.json(rows.map(row => ({
            id: row.id,
            documentType: row.document_type,
            fileName: row.file_name,
            fileSize: row.size_bytes,
            mimeType: row.mime_type,
            uploadedAt: row.uploaded_at,
            notes: row.notes
        })));
    } catch (err) {
        console.error('Error fetching documents:', err);
        res.status(500).json({ error: 'Failed to fetch documents' });
    }
});

// Download/View a document
app.get('/api/documents/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query('SELECT * FROM accreditation_documents WHERE id = ?', [id]);
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Document not found' });
        }

        const document = rows[0];
        req.auditResourceName = document.file_name;
        const filePath = path.join(__dirname, 'uploads', document.file_path);

        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'File not found on disk' });
        }

        res.download(filePath, document.file_name);
    } catch (err) {
        console.error('Error downloading document:', err);
        res.status(500).json({ error: 'Failed to download document' });
    }
});

// Delete a document
app.delete('/api/documents/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query('SELECT * FROM accreditation_documents WHERE id = ?', [id]);
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Document not found' });
        }

        const document = rows[0];
        req.auditResourceName = document.file_name;
        const filePath = path.join(__dirname, 'uploads', document.file_path);

        // Delete from database
        await pool.query('DELETE FROM accreditation_documents WHERE id = ?', [id]);

        // Delete from disk
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }

        res.json({ success: true, message: 'Document deleted successfully' });
    } catch (err) {
        console.error('Error deleting document:', err);
        res.status(500).json({ error: 'Failed to delete document' });
    }
});

// --- Readiness Checklist Routes ---

// Get checkpoints for an accreditation
app.get('/api/accreditations/:id/checkpoints', async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.query(
            'SELECT * FROM accreditation_checkpoints WHERE accreditation_id = ? ORDER BY id',
            [id]
        );
        res.json(rows.map(row => ({
            id: row.id,
            checkpointName: row.checkpoint_name,
            isCompleted: row.is_completed === 1,
            updatedAt: row.updated_at
        })));
    } catch (err) {
        console.error('Error fetching checkpoints:', err);
        res.status(500).json({ error: 'Failed to fetch checkpoints' });
    }
});

// Update a checkpoint (toggle completion)
app.put('/api/checkpoints/:id', async (req, res) => {
    const { id } = req.params;
    const { isCompleted } = req.body;
    try {
        // First, update the checkpoint
        await pool.query(
            'UPDATE accreditation_checkpoints SET is_completed = ? WHERE id = ?',
            [isCompleted ? 1 : 0, id]
        );

        // If completed, check if all checkpoints for this accreditation are now done
        if (isCompleted) {
            const [checkRows] = await pool.query('SELECT c.accreditation_id, c.checkpoint_name, a.programme_name FROM accreditation_checkpoints c JOIN accreditations a ON c.accreditation_id = a.id WHERE c.id = ?', [id]);
            const accId = checkRows[0]?.accreditation_id;
            req.auditResourceName = `${checkRows[0]?.programme_name} (${checkRows[0]?.checkpoint_name})`;

            if (accId) {
                const [totalRows] = await pool.query('SELECT COUNT(*) as count FROM accreditation_checkpoints WHERE accreditation_id = ?', [accId]);
                const [doneRows] = await pool.query('SELECT COUNT(*) as count FROM accreditation_checkpoints WHERE accreditation_id = ? AND is_completed = 1', [accId]);

                if (totalRows[0].count > 0 && totalRows[0].count === doneRows[0].count) {
                    // Fetch accreditation info for the email
                    const [accRows] = await pool.query('SELECT programme_name, email FROM accreditations WHERE id = ?', [accId]);
                    const acc = accRows[0];

                    if (acc && acc.email) {
                        try {
                            await sendEmail(
                                acc.email,
                                `QA Complete: ${acc.programme_name} is Ready for GTEC Submission`,
                                `
                                <h2>Internal Quality Assurance Complete!</h2>
                                <p>Congratulations!</p>
                                <p>All internal readiness checkpoints for <strong>${acc.programme_name}</strong> have been successfully completed.</p>
                                <p>The programme has passed the internal quality review and is now officially ready for submission to the <strong>Ghana Tertiary Education Commission (GTEC)</strong>.</p>
                                <p>Best regards,<br>Quality Assurance Unit</p>
                                `
                            );
                            console.log(`Final Readiness email sent for: ${acc.programme_name}`);
                        } catch (emailErr) {
                            console.error('Failed to send readiness email:', emailErr);
                        }
                    }
                }
            }
        }

        res.json({ success: true });
    } catch (err) {
        console.error('Error updating checkpoint:', err);
        res.status(500).json({ error: 'Failed to update checkpoint' });
    }
});

// Initialize default checkpoints for an accreditation
app.post('/api/accreditations/:id/initialize-checkpoints', async (req, res) => {
    const { id } = req.params;
    const defaultCheckpoints = [
        'Self-Assessment Report Drafted',
        'Curriculum Review Completed',
        'Staff Documentation Verified',
        'Infrastructure Assessment',
        'Internal QA Approval',
        'Application Submitted to GTEC'
    ];

    try {
        // Check if already initialized
        const [existing] = await pool.query('SELECT count(*) as count FROM accreditation_checkpoints WHERE accreditation_id = ?', [id]);
        if (existing[0].count > 0) {
            return res.json({ success: true, message: 'Already initialized' });
        }

        for (const name of defaultCheckpoints) {
            await pool.query(
                'INSERT INTO accreditation_checkpoints (accreditation_id, checkpoint_name) VALUES (?, ?)',
                [id, name]
            );
        }
        res.json({ success: true, message: 'Checkpoints initialized' });
    } catch (err) {
        console.error('Error initializing checkpoints:', err);
        res.status(500).json({ error: 'Failed to initialize checkpoints' });
    }
});

app.get('/api/health', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT COUNT(*) as count FROM accreditations');

        let emailStatus = 'unknown';
        let emailError = null;

        try {
            const verification = await verifyConnection();
            emailStatus = verification.success ? 'connected' : 'auth_failed';
            emailError = verification.error || null;
        } catch (err) {
            emailStatus = 'error';
            emailError = err.message;
        }

        res.json({
            status: 'ok',
            email_service: emailStatus,
            email_error: emailError,
            accreditations: rows[0].count
        });
    } catch (err) {
        res.status(500).json({ status: 'error', error: err.message });
    }
});

// Runs every day at 9:00 AM
cron.schedule('0 9 * * *', async () => {
    console.log('Running daily accreditation check...');
    try {
        const [rows] = await pool.query('SELECT * FROM accreditations WHERE email IS NOT NULL');
        // Target intervals: 1 day, 1 week, 2 weeks, 1 month (30 days), 6 months (180 days), 1 year (365 days), 15 months (450 days)
        const targetDays = [1, 7, 14, 30, 180, 365, 450];

        for (const row of rows) {
            // Check if snoozed
            if (row.snoozed_until && new Date(row.snoozed_until) > new Date()) {
                console.log(`Skipping snoozed reminder for ${row.programme_name}`);
                continue;
            }

            const { days } = getStatus(row.expiry_date);

            if (targetDays.includes(days)) {
                console.log(`Sending auto-reminder for ${row.programme_name} (Expires in ${days} days)`);
                await sendEmail(
                    row.email,
                    `Action Required: Accreditation Expiring in ${days} Days - ${row.programme_name}`,
                    `<p>The accreditation for <strong>${row.programme_name}</strong> expires in <strong>${days} days</strong>.</p><p>Please take necessary action to renew the accreditation.</p>`
                );
            }
        }
    } catch (err) {
        console.error('Error in daily accreditation check:', err);
    }
});

// Runs on the 1st of every month at 8:00 AM
cron.schedule('0 8 1 * *', async () => {
    console.log('Running scheduled monthly Pro-VC report...');
    await sendMonthlyReport();
});

// Automated Database Backup Logic
async function sendDatabaseBackup() {
    console.log('Generating university database backup...');
    try {
        const [accreditations] = await pool.query('SELECT * FROM accreditations');
        const [users] = await pool.query('SELECT id, username, email, role, status, created_at FROM users');
        const [auditLogs] = await pool.query('SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 5000');

        const backupData = {
            system: 'HTU Accreditation Monitoring System',
            backup_at: new Date().toISOString(),
            data: {
                accreditations,
                users,
                audit_logs: auditLogs
            }
        };

        const backupContent = JSON.stringify(backupData, null, 2);
        const fileName = `HTU_Accreditation_Backup_${new Date().toISOString().split('T')[0]}.json`;

        const result = await sendEmail(
            'accreditationsystem@htu.edu.gh',
            `System Backup: HTU Accreditation Data - ${new Date().toLocaleDateString()}`,
            `
            <h2>University Data Backup</h2>
            <p>Attached is the automated daily backup for the <strong>HTU Accreditation Monitoring System</strong>.</p>
            <p><strong>Generation Time:</strong> ${new Date().toLocaleString()}</p>
            <p>This file contains all programme records, user accounts, and recent audit logs for disaster recovery purposes.</p>
            `,
            [{
                filename: fileName,
                content: backupContent
            }]
        );

        if (result.success) {
            console.log('Daily backup email sent successfully.');
        } else {
            console.error('Failed to send backup email:', result.error);
        }
    } catch (err) {
        console.error('Error during database backup generation:', err);
    }
}

// Runs every day at 12:00 PM (Noon)
cron.schedule('0 12 * * *', async () => {
    console.log('Triggering scheduled noon backup...');
    await sendDatabaseBackup();
});

// Optional: Temporary route to trigger backup for testing (Super Admin only)
app.post('/api/trigger-backup', async (req, res) => {
    try {
        const userEmail = req.headers['x-user-email'];
        const [userRows] = await pool.query('SELECT role FROM users WHERE email = ?', [userEmail]);
        if (userRows.length === 0 || userRows[0].role !== 'super_admin') {
            return res.status(403).json({ error: 'Access denied' });
        }
        await sendDatabaseBackup();
        res.json({ success: true, message: 'Backup triggered and sent to system email.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// Note: In cPanel/Passenger, the frontend is served separately by Apache in public_html.
// We only need this app to handle /api requests.

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`HTU Accreditation Backend Started on port ${PORT}`);
});


